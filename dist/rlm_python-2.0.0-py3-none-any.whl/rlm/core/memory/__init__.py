"""Memory module - Efficient context handling."""

from rlm.core.memory.handle import ContextHandle

__all__ = ["ContextHandle"]
