"""Configuration module for RLM."""

from rlm.config.settings import RLMSettings, settings

__all__ = ["RLMSettings", "settings"]
