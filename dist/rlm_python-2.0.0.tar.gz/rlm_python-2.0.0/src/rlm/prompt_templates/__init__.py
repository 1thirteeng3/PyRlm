"""Prompt templates module."""

from rlm.prompt_templates.system import SYSTEM_PROMPT, get_system_prompt

__all__ = ["SYSTEM_PROMPT", "get_system_prompt"]
